<?php 



?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<title>
Get updated</title><img src="images/GET.jpg" width="100%" height="600px" />
</head>


<Body>
	


This is a project that I started way back in high school

This web is to help youths update each othe on the latest stuff online
This web shall entails the following:

<ol>
<li><a href="#rides">cars</a>
<li><a href="#Nganya">Nganya</a>
<li><a href="#clads">Maclady</a>
<li><a href="#social">Socialites</a>
</ol>



<a name="Nganya"></a><h3> Nganya</h3>
if you wonnna cheak out the latest oin the Nganya industries, <a href="nganya/index.php">click here</a> 

<a name="rides"></a><h3>Rides</h3>
<p>If you wonna see the latest rides in Kenya right now, click here</p>
<p>lets just say for a sec you wonna compare between two of ur dream cars, you dont realy have to go to youtube, google and every other site just click here and showyou how</p>

<a name="clads"></a><h3>Clads</h3>
<p>for the fassion freeks, click here </p>

<a name="social"></a><h3>Socialites</h3>
<p>Cheak out ur socialite here</p>













</Body>
</html>
<?php

$db = mysqli_connect('localhost', 'root', '', 'get_updated');

if ($db===false) {

 die("sorry no connection made to the target system").mysqli_connect_error();
}






?>
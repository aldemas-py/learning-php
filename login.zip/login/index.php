<?php

include_once('core.inc.php');

require_once('connect.inc.php');

include('login.inc.php');



?>
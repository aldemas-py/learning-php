<?php
if(isset($_POST['submit'])){
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if(!empty($username) && !empty($password)){
		
	$query = "SELECT `id` FROM login WHERE `username` = '$username' AND `password` = '$password'";
		
	$exc = mysqli_query($connect, $query);
	
	if(mysqli_num_rows($exc)==0){
		
		echo 'invalid username or password combination';
	
	} else if(mysqli_num_rows($exc)!=0){
				
		$userid = mysql_result()
	
	
	
	}
		
	}
	
	
}




?>

<form action="<?php echo $current_file;?>" method="POST">
<div>
	<div>
	<label>username</label>
	<input type="text" name="username">
	</div>
	
	<div>
		<label>password</label>
		<input type="password" name="password">
	</div>
	
	<div>
		<input type="submit" name="submit" id="submit">
	<div>


<div>


</form>